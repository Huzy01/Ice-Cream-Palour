﻿function baseInformation(){
  var strFirstName = "";
  var strLastName = "";
  var intAge = 0;
  
  var strFullName = "";

  var priceKnickerbocker = 5;
  var pricePistachio = 3.9;
  var priceStrawberryIce = 3.5;
  var runningTotal = 0;
  var calculations = 0;
  var age = 0;


// *************************************************************************************
// ******************* Obtains the inputs from each text box ***************************
// *************************************************************************************
  
//Identifies the element nodes using their ID from the HTML.
  strFirstName = document.getElementById("firstname").value;
  strLastName = document.getElementById("lastname").value;
  intAge = document.getElementById("age").value;

// *************************************************************************************
// ****************** The program processes and outputs        *************************
// ****************** some of the inputs                       *************************
// *************************************************************************************
  
// ???????? The program has a small bug because it displays multiple names and ages ???
// ???????? for as long as OK is clicked. It needs to check if there is a lastchild  ???
// ???????? and if there is delete it. There needs to be a check because the first   ???
// ???????? there will not be a lastChild and the program hangs.                     ???



//Processes the inputs by joining the first name and second name together.
  strFullName = document.createTextNode(strFirstName + " " + strLastName);
  document.getElementById("fullname").appendChild(strFullName);
  
//Processes the inputs by getting the age from the text box and displaying it on the page.
  age = document.createTextNode(intAge);
  document.getElementById("ageoutput").appendChild(age);

//Series of If... statements to check if any of the checkboxes have been ticked and
//if they have, add the price to the running total.
  if (document.getElementById('knickerbockerGlory').checked) {
      document.getElementById("knickerbockerplaceholder").setAttribute("src", "images/knickerbockerGlory_sml.jpg");
      runningTotal = runningTotal + priceKnickerbocker;
  }
  else {
    document.getElementById("knickerbockerplaceholder").setAttribute("src","images/placeholder_sml.gif");
  }

  if (document.getElementById('pistachioCones').checked) {
      document.getElementById("pistachioplaceholder").setAttribute("src", "images/pistachioCones_sml.jpg");
      runningTotal = runningTotal + pricePistachio;
  }
  else {
    document.getElementById("pistachioplaceholder").setAttribute("src","images/placeholder_sml.gif");
  }

  if (document.getElementById('strawberryIce').checked) {
      document.getElementById("strawberryiceplaceholder").setAttribute("src", "images/strawberryIce_sml.jpg");
      runningTotal = runningTotal + priceStrawberryIce;
  }
  else {
    document.getElementById("strawberryiceplaceholder").setAttribute("src","images/placeholder_sml.gif");
  }

//Output - displays the value of the running total in the output section of the page.
  calculations = document.createTextNode(runningTotal);
  document.getElementById("prices").appendChild(calculations);
}


function Clear() {
//priceField.removeChild(priceField.childNodes[0]);
//Works best with lastChild as the price that has been added is identified by javascript.
//Using the array is good targetting but there are two nodes, there seems to be a space added
//and this makes it difficult to specify the array/collection index.
//Could loop through the array/collection but the code needs to be simple for intermediate use.


var priceField=document.getElementById("prices");
priceField.removeChild(priceField.lastChild);

var nameField=document.getElementById("fullname");
nameField.removeChild(nameField.lastChild);

var ageField = document.getElementById("ageoutput");
ageField.removeChild(ageField.lastChild);
}